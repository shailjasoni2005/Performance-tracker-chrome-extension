import React from "react";
import { BrowserRouter as Router,Routes,Route } from "react-router-dom";
import Homepage from "./components/homepage/Homepage";
import Login from "./components/login/login";
import SignUp from "./components/signup/signup";

function App() {
  return (
    <>
    <Router>
      <Routes> 
        <Route path="/" element={<Homepage/>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/signup" element={<SignUp/>} />
      </Routes>
    </Router>
    </>
  );
}

export default App;
