import React from "react";
import "./signup.css"; // Import the CSS file

function SignUp() {
  return (
    <div className="signup-container">
      <div className="signup-card">
        <h2>Create an Account</h2>
        <form action="#" method="POST">
          <input type="text" placeholder="Full Name" required />
          <input type="email" placeholder="Email Address" required />
          <input type="password" placeholder="Password" required />
          <input type="password" placeholder="Confirm Password" required />
          <button type="submit">Sign Up</button>
        </form>
        <p>
          Already have an account?{" "}
          <a href="login.html">Login here</a>
        </p>
      </div>
    </div>
  );
}

export default SignUp;
