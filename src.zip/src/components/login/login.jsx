import React from "react";
import "./login.css"; // Import the CSS file

function Login() {
  return (
    <div className="container">
      <div className="form-container login-container">
        <form action="#" method="POST">
          <h2>Login</h2>
          <input type="email" placeholder="Email" required />
          <input type="password" placeholder="Password" required />
          <button type="submit">Login</button>
        </form>
        <p>
          Don't have an account?{" "}
          <a href="signup.html">Sign up</a>
        </p>
      </div>
    </div>
  );
}

export default Login;
